#!/usr/bin/perl -sw
##
## Code::Contribution::Distribution - Find code owners from source files. 
##
## $Date: 2000/01/02 21:53:28 $
## $Revision: 0.23 $
## $State: Exp $
## $Author: root $
## 
## Copyright (c) 1998, Vipul Ved Prakash.  All rights reserved.
## This code is free software; you can redistribute it and/or modify
## it under the same terms as Perl itself.

package Code::Contribution::Distribution; 
use Persistence::Object::Simple; 
use File::Recurse; 
use Math::BigInt; 

use vars qw( $AUTOLOAD $VERSION ); 

@ISA          = ( Persistence::Object::Simple ); 
( $VERSION )  = '$Revision: 0.23 $' =~ /\s(\d+\.\d+)\s/;  
my $FILETYPES = '(?:\.c|\.pm|\.pl|\.PL|\.S|\.cgi)$'; 
my $ID        = "Code Contribution Distribution Data Parser - v$VERSION"; 

sub new {

    my ( $class, %args ) = @_; 
    my ( $dir, $fn, $path ); 

    if ( $args{ Package } ) { 
        $dir = $args{ Package }; 
        $dir =~ s:([^/]+)/?$::; 
        $fn = "$1" . ".codd"; 
    }

    $dir = $args{ Dir  } || $dir;
    $fn  = $args{ Codd } || $fn; 
    $path = $dir ? "$dir/$fn" : $fn; 
    
    my $self = $class->SUPER::new ( __Fn => $path ); 

    $self->package   ( $args{ Package } ) if $args{ Package }; 
    $self->version   ( $VERSION         ) unless $self->version; 
    $self->codd      ( $fn ) unless $self->codd; 
    $self->verbose   ( $args{ Verbose } ) if $args{ Verbose }; 
    $self->filetypes ( $args { Filetypes } || $FILETYPES ); 
    $self->id        ( $ID ); 
    return $self; 

}

sub ownergrep {

    my ( $self, %args ) = @_; 
    my $packagesize = new Math::BigInt '0'; 

    my @codefiles; 
    my $ft = $self->filetypes; 
    recurse { /$ft/o && push @codefiles, $_ } $self->package (); 


    print "Processing package -- ", $self->package, ", $#codefiles files.\n\n";  
    for ( @codefiles ) { 

        open C, $_; 
        my @code = <C>;  my $code = join'', @code; chomp @code; 
        my @tmp = stat ( C ); 
        my $size = $tmp[ 7 ]; 
        $packagesize += $size; 
        close C; 

        print "    o greping $_, $size bytes...\n" if $self->verbose; 
        my $cr     = $self->copyrights ( \@code ) if $code =~ /copyright/i; 
        my $emails = $self->emails ( \@code ) if $code =~ /\@/; 
        my $logins = $self->logins ( \@code ) if $code =~ /Header|Id/i; 
        push @$cr, @$emails, @$logins; 
        for ( @$cr ) { $_ = lc };

        my $total = scalar @$cr; 

        if ( $total == 0 ) { 
            $self->{ uncredited } = $self->{ uncredited } + $size; 
        } else { 
            for ( @$cr ) { 
                $self->{ $_ } = $self->{ $_ } + int ( $size / $total ) 
            }
        }

    } 

    $self->packagesize ( $packagesize ); 
    $self->commit (); 
    print "\nUPDATED ", $self->codd, ", $packagesize bytes.\n\n" if $self->verbose; 

}

    
sub copyrights { 

    my ( $self, $code ) = @_; 
    my @copy; 

    for ( @$code ) {
        if (/copyright/i) { 
            ( m%.*copyright (?:\(c\)\s+)?[\d\,\-\s\:]+(?:by\s+)?([^\d]*)%i ) && push @copy, $1; 
        }
    }

    # -- Clean the mess. 
    my $index = -1; 
    for ( @copy ) { 
        $index++; $_ = lc; 
        s:\s+$::; s:[\(<"\[\\\*].*$::;
        s:([a-z]{2,})\..*$:$1:; s:^by::; 
        s:\.\s{2,}.*::; s:\s{3,}.*$::; 
        s:\.\s+all .*::; s:[\.,\n\s]+$::; 
        if ( /\s+(?:and|\&)\s+/i )  { 
            my @names = split /\s+(?:and|\&)\s+/i;
            push @copy, @names; 
            splice @copy, $index, 1
        }
        splice @copy, $index, 1 unless m:[a-z]+:; 
    }

    return \@copy; 

}

sub logins { 

    my ( $self, $code ) = @_; 
    my @ids; 

    LINE: for ( @$code ) { 
        next LINE unless /Id|Header/i; 
        my @m = $_ =~ /(?:Id|Header).*?\d\d\:\d\d\:\d\d (\S+?) \S+?/gi;
        push @ids, @m if @m; 
    }

    for ( @ids ) { $_ = "login-$_" }
    return \@ids;

}

sub emails { 

    my ( $self, $code ) = @_; 
    my @emails; 
    
    LINE: for ( @$code ) { 
        next LINE unless /\@/; 
        my @m = $_ =~ /([\d\w_\=\.\%]+?\@[\d\w\._]+?\.\w+?)(?=[\s:>])/gi;
        for ( @m ) { s:^.*<::; push @emails, $_ }; 
    }

    return \@emails;

}

sub merge { 

    my ( $self, $coddname ) = @_; 
    my   $class = ref $self; 
    my   $total = $self->packagesize || new Math::BigInt '0'; 

    my $codd = $class->new ( Codd => $coddname ); 

    for ( keys %$codd ) { 
        unless ( /^__/ ) { 
            $self->{ $_ } += $codd->{ $_ }; 
        }
    } 

    if ( $codd->packagesize ) { 
        $total += $codd->packagesize;
        $self->packagesize ( $total ); 
    } 

}

    
sub AUTOLOAD { 

        my ( $self, $value ) = @_;
        my $key = $AUTOLOAD;  $key =~ s/.*://;

        if ( $value ) { $self->{ "__$key" } = $value }

        return $self->{ "__$key" };   

}

'True Value' 

